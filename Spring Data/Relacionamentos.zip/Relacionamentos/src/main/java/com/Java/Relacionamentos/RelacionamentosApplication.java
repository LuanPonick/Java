package com.Java.Relacionamentos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RelacionamentosApplication {

	public static void main(String[] args) {
		SpringApplication.run(RelacionamentosApplication.class, args);
	}

}
