package com.Java.Relacionamentos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RelacionamentosApplicationTests {

	@Test
	void contextLoads() {
	}

}
