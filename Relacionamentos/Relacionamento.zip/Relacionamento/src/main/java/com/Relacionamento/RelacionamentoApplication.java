package com.Relacionamento;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RelacionamentoApplication {

	public static void main(String[] args) {
		SpringApplication.run(RelacionamentoApplication.class, args);
	}

}
