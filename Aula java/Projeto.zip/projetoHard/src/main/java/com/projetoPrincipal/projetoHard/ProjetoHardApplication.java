package com.projetoPrincipal.projetoHard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoHardApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoHardApplication.class, args);
	}

}
