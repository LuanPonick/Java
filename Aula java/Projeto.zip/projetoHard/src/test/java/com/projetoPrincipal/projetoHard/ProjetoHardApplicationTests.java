package com.projetoPrincipal.projetoHard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoHardApplicationTests {

	@Test
	void contextLoads() {
	}

}
